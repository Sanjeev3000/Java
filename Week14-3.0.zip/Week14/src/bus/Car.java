package bus;

import data.CarDB;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Scanner;

public class Car extends Vehicule {
    private double price;
    private String gear;

    public String getGear() {
        return gear;
    }

    public void setGear(String gear) {
        this.gear = gear;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    public Car()
    {
        super();

    }
    public Car(int i,Date d,String m,String c,String com,double p,String gear)
    {
        super(i,d,m,c,com);
        this.gear=gear;
        this.price=p;
    }

    @Override
    public String toString() {
        return super.toString()+", Gear="+gear+", price="+price+"]";
    }

    public static int Add(Car car)throws SQLException,ParseException {return CarDB.Add(car);}
    public static int Add(int id,int year,int month,int day,String model,String color,String company,double price,String gear) throws SQLException,ParseException{return  CarDB.Add(id, year, month, day, model, color, company, price, gear);}
    public static int Delete(int key){return CarDB.Delete(key);}
    public static int Update(int key,int choice,Scanner scanner){

        if(choice==1)
        {
            Date date=new Date();

            System.out.println("Day:");
            date.setDay(scanner.nextInt());
            System.out.println("Month:");
            date.setMonth(scanner.nextInt());
            System.out.println("Year:");
            date.setYear(scanner.nextInt());
            return CarDB.UpdateDate(key,date);
        }
        if (choice==2)
        {
            System.out.println("Model:");
            String model=scanner.next();
            return CarDB.UpdateModel(key,model);
        }
        if (choice==3)
        {
            System.out.println("Color:");
            String color=scanner.next();
            return CarDB.UpdateColor(key,color);
        }
        if (choice==4)
        {
            System.out.println("Company:");
            String company=scanner.next();
            return CarDB.UpdateCompany(key,company);
        }
        if(choice==5)
        {
            System.out.println("Price:");
            double price=scanner.nextDouble();
            return CarDB.UpdatePrice(key,price);
        }
        if(choice==6)
        {
            System.out.println("Gear:");
            String gear=scanner.next();
            return CarDB.UpdateGear(key,gear);
        }
        if(choice==7)
        {
            System.out.println("ID:");
            int id=scanner.nextInt();
            return CarDB.Update(key,id);
        }
        else
            {
                return -1;
            }
    }
    public static Car Search(int key){
        return CarDB.Search(key);
    }
    public static HashMap<Integer,Car> GetList(){
        return CarDB.getList();
    }
}

