package bus;

public class Vehicule {
    private int id;
    private Date date;
    private String color;
    private String model;
    private String Company;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getModel() {
        return model;
    }

    public String getCompany() {
        return Company;
    }

    public void setCompany(String company) {
        Company = company;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Date getDate() {
        return date;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setDate(Date date) {
        this.date = date;
    }
    public Vehicule()
    {
        this.id=000;
        this.date=new Date();
        this.model="";
        this.color="";
        this.Company="";
    }
    public Vehicule(int i,Date d,String m,String c,String com)
    {
        this.id=i;
        this.date=d;
        this.model=m;
        this.color=c;
        this.Company=com;
    }
    @Override
    public String toString() {
        return "Vehicule [id="+id+", date=" +date+", color="+color+", model="+model+", Company="+Company;
    }



}
