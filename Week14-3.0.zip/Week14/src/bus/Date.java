package bus;

public class Date {
    private int day;
    private int month;
    private int year;

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }


    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }


    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public Date()
    {
        this.day=00;
        this.month=00;
        this.year=00;

    }
    public Date(int d,int m,int y)
    {
        this.day=d;
        this.month=m;
        this.year=y;

    }

    @Override
    public String toString() {
        return "("+this.getYear()+"-"+this.getMonth()+"-"+this.getDay()+")";
    }
}
