package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionDB {

    public static Connection getDBConnection() throws SQLException {

        Connection myConnection;
        try{
            String username = "system";
            String password = "sa";
            String service = "localhost";
            String url = "jdbc:oracle:thin:";

            myConnection = DriverManager.getConnection(url+username+"/"+password+"@"+service);

        }
        catch (SQLException ex){
            System.out.println(ex.getMessage());
            return null;
        }
        return myConnection;
    }

}
