package data;
import bus.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
public class CarDB {

    public static int DMLProcess(String DMLRequest) {
        int succes = -1;
        try {
            Connection myConnection = ConnectionDB.getDBConnection();

            Statement myStatement = myConnection.createStatement();

            //String request = DMLRequest;

            succes = myStatement.executeUpdate(DMLRequest);

            myConnection.commit();
            myConnection.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return succes;
    }
    public static int Add(Car current) throws SQLException,ParseException
    {

        return CarDB.DMLProcess("insert into Car (id,cdate,model,color,company,price,gear)" +
               //values (1,TO_DATE('1/6/1999'
                "values ("+current.getId()+",TO_DATE(\'"+current.getDate().getDay()+"/"+current.getDate().getMonth()+"/"+current.getDate().getYear()+"\',\'MM/DD/YYYY\')"+",\'"+current.getModel()+"\'"+",\'"+current.getColor()+"\'"+",\'"+current.getCompany()+"\'"+","+current.getPrice()+",\'"+current.getGear()+"\'"+")"
        );
    }
    public static int Add(int id,int year,int month,int day,String model,String color,String company,double price,String gear)throws SQLException,ParseException{
        int done = -1;
        try {
        String s=(year+"-"+month+"-"+day).toString();
        java.util.Date util=new SimpleDateFormat("yyyy-MM-dd").parse(s);
        java.sql.Date date= new java.sql.Date(util.getTime());
        PreparedStatement statement=ConnectionDB.getDBConnection().prepareStatement("INSERT into Car (id,cdate,model,color,company,price,gear) values(?,?,?,?,?,?,?)");
        statement.setInt(1,id);
        statement.setDate(2,date);
        statement.setString(3,model);
        statement.setString(4,color);
        statement.setString(5,company);
        statement.setDouble(6,price);
        statement.setString(7,gear);
        done=statement.executeUpdate();
        ConnectionDB.getDBConnection().commit();
        } catch (Exception e) {
            // TODO: handle exception
        }

        return done;
    }
    public static int Delete(int key)
    {
        return CarDB.DMLProcess("delete from Car where id="+key);
    }
    public static int Update(int key,int newkey)
    {
        return CarDB.DMLProcess("update Car set id = \'" +newkey+ "\' where id=" + key);
    }
    public static int UpdateDate(int key,Date date)
    {
        return CarDB.DMLProcess("update Car set cdate = TO_DATE(\'"+date.getMonth()+"/"+date.getDay()+"/"+date.getYear()+"\',\'MM/DD/YYYY\') where id=" + key);
    }
    public static int UpdateModel(int key,String model )
    {
        return CarDB.DMLProcess("update Car set model = \'" +model+ "\' where id=" + key);
    }
    public static int UpdateColor(int key,String color)
    {
        return CarDB.DMLProcess("update Car set color = \'" +color+ "\' where id=" + key);
    }
    public static int UpdateCompany(int key,String company)
    {
        return CarDB.DMLProcess("update Car set company = \'" +company+ "\' where id=" + key);
    }
    public static int UpdatePrice(int key,double price)
    {
        return CarDB.DMLProcess("update Car set price ="+price+"where id=" + key);
    }
    public static int UpdateGear(int key,String gear)
    {
        return CarDB.DMLProcess("update Car set gear = \'" +gear+ "\' where id=" + key);
    }
    public static Car Search(int key)
    {
        try {
            Connection myConnection = ConnectionDB.getDBConnection();

            Statement myStatement = myConnection.createStatement();

            String query="select * from Car where id="+key;

            ResultSet results=myStatement.executeQuery(query);

            if (results.next())
            {
                Date date=new Date(results.getDate("cdate").toLocalDate().getDayOfMonth(),results.getDate("cdate").toLocalDate().getMonthValue(),results.getDate("cdate").toLocalDate().getYear());
                Car aCar=new Car(results.getInt("id"),date,results.getString("model"),results.getString("color"),results.getString("company"),results.getDouble("price"),results.getString("gear"));
                myConnection.close();
                return aCar;
            }
            else
            {
                myConnection.close();
                return null;
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    public static  HashMap<Integer, Car>  getList(){

        HashMap<Integer, Car>  myList = new  HashMap<Integer, Car>();
        try {
            Connection myConnection = ConnectionDB.getDBConnection();
            String myQuery = "select * from Car";
            Statement myStatement;
            ResultSet resultSet;
            myStatement = myConnection.createStatement();
            resultSet  =  myStatement.executeQuery(myQuery);

            while(resultSet.next()){
                String id = resultSet.getString(1);
                Date date=new Date(resultSet.getDate("cdate").toLocalDate().getDayOfMonth(),resultSet.getDate("cdate").toLocalDate().getMonthValue(),resultSet.getDate("cdate").toLocalDate().getYear());
                String model=resultSet.getString(3);
                String c=resultSet.getString(4);
                String com=resultSet.getString(5);
                Double p=resultSet.getDouble(6);
                String gear=resultSet.getString(7);
                Car current =new Car(Integer.parseInt(id),date ,model,c,com,p,gear);
                myList.put(((Car)current).getId(),current);

            }
            myConnection.close();
        }
        catch(SQLException e){
            //System.out.println(e.toString());
            e.printStackTrace();
        }
        return myList;
    }
}
