package prod;

import bus.*;
import data.CarDB;
import data.ConnectionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.*;

public class Tester {
    public static boolean TableExist(Connection currentConnection,String table)throws SQLException
    {
        List<String> listoftable=new ArrayList<>();
        String sqlString = "SELECT table_name FROM user_tables; " ;
        try{

            Statement  currentStatement  = currentConnection.createStatement();
            ResultSet resultSet=currentStatement.executeQuery(sqlString);

            while (resultSet.next())
            {

                listoftable.add(resultSet.getString("TABLE_NAME"));
            }

            currentConnection.close();

        } catch (SQLException ex)
        {
            System.out.println(ex.getMessage());
        }
        for (String name:listoftable){
            if(name==table)
            {
                return true;
            }

        }
        return false;
    }
    public static void createTable(Connection currentConnection)throws SQLException
    {

        String sqlString = "create table Car (id number, cdate DATE,model varchar(50),color varchar(50),company varchar(50),price number ,gear varchar(50),CONSTRAINT id_pk PRIMARY KEY (id))" ;
        if(!TableExist(currentConnection,"Car")) {
            try {

                Statement currentStatement = currentConnection.createStatement();
                currentStatement.execute(sqlString);

                currentConnection.commit();
                currentConnection.close();

            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }
    public static int menu(Scanner scanner){
        int choice;
        System.out.println("1.Display");
        System.out.println("2.Add");
        System.out.println("3.Search");
        System.out.println("4.Delete");
        System.out.println("5.Update");
        choice=scanner.nextInt();
        return choice;
    }
    public static int upmenu(Scanner scanner){
        int choice;

        System.out.println("1.Date");
        System.out.println("2.Model");
        System.out.println("3.Color");
        System.out.println("4.Company");
        System.out.println("5.Price");
        System.out.println("6.Gear");
        System.out.println("7.Id");
        choice=scanner.nextInt();
        return choice;
    }
     public static void main(String[] args) throws SQLException, ParseException {

         createTable(ConnectionDB.getDBConnection());
         Scanner scan = new Scanner(System.in);
         int key;
         HashMap<Integer, Car> myList;
         do{

             int opt=menu(scan);
             switch (opt)
             {
                 case 1:
                     System.out.println("Display....");
                        myList=Car.GetList();
                    for (Car elememt:myList.values())
                     {
                        System.out.println(elememt);
                     }
                                             break;
                 case 2:
                     System.out.println("Adding");
                     System.out.println("ID:");
                     int id=scan.nextInt();
                     System.out.println("year:");
                     int year=scan.nextInt();
                     System.out.println("month:");
                     int month=scan.nextInt();
                     System.out.println("day:");
                     int day=scan.nextInt();
                     //String model,String color,String company,double price,String gear
                     System.out.println("Model:");
                     String model=scan.next();
                     System.out.println("Color:");
                     String color=scan.next();
                     System.out.println("Company:");
                     String company=scan.next();
                     System.out.println("Price:");
                     double price=scan.nextDouble();
                     System.out.println("Gear:");
                     String gear=scan.next();

                     Car.Add(id,year,month,day,model,color,company,price,gear);
                     System.out.println("DONE");

                     break;
                 case 3:
                     System.out.println("key:");
                     key=scan.nextInt();
                     Car s=Car.Search(key);
                     System.out.println(s);
                     break;
                 case 4:
                     System.out.println("key:");
                     key=scan.nextInt();
                     Car.Delete(key);
                     System.out.println("Done");
                     break;
                 case 5:
                     int umenu=upmenu(scan);
                     System.out.println("ID:");
                     key=scan.nextInt();
                     Car.Update(key,umenu,scan);
                     System.out.println("Completed");

                     break;


             }

         }
         while (true);

      }
}
